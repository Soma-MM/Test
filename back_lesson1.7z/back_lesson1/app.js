const express =  require('express');
require('dotenv').config();

const app = express();

app.get('/',function(req,res){
    res.send(`<h2 style="color:red">Testing</h2>`)
})


app.get('/Contact',function(req,res){
    res.send('<h2 style="color:blue">Contact</h2>')
})


app.get('/About',function(req,res){
    res.send('<h2 style="color:purple">About</h2>')
})


app.get('/Details',function(req,res){
    res.send('<h2 style="color:orange">Details</h2>')
})

app.listen(process.env.PORT)